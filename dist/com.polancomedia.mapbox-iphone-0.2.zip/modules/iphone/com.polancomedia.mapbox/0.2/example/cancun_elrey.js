exports.win = function(args){
	//create a map with local mbtiles file that contains coverage of entire globe
	var win = Ti.UI.createWindow({
		title: 'Offline Map',
		backgroundColor:'white'
	});
	
	var mapbox = require('com.polancomedia.mapbox');
	
	var mapView = mapbox.createView({
		map: '/maps/OSMMexico',
		minZoom: 17,
		maxZoom: 22,
		zoom: 17,
		centerLatLng: [21.0614, -86.7815],
		width: Ti.UI.FILL,
		height: Ti.UI.FILL,
		userLocation: true
	});
	
	win.add(mapView);

	mapView.addEventListener('singleTapOnMap', function(e){
		Ti.API.info('singleTapOnMap ' + JSON.stringify(e));
	})
	
	//win.add(require('toolbar').init(mapView));
	return win;
}

